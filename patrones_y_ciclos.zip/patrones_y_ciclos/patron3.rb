n = ARGV[0].to_i

    (n-14).times do
        print "121212121212121"
    end 
    print "\n"

