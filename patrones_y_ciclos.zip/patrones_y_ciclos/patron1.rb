n = ARGV[0].to_i

    (5).times do
        print "*."
    end 
    print "\n"