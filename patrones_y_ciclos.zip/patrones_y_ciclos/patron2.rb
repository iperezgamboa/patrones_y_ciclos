n = ARGV[0].to_i

    (n-9).times do
        print "**.."
        print "**.."
        print "**"
    end 
    print "\n"