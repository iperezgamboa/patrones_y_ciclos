n = ARGV[0].to_i

    (n-17).times do
        print "123123123123123123"
    end 
    print "\n"
